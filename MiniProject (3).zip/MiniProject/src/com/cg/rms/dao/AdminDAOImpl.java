package com.cg.rms.dao;

import java.util.ArrayList;

import com.cg.rms.beans.Candidate;
import com.cg.rms.exception.RecruitmentException;

public class AdminDAOImpl implements AdminDAO {

    @Override
    public ArrayList<Candidate> searchPlacedMonth(String month)
            throws RecruitmentException {
        
        return null;
    }

    @Override
    public ArrayList<Candidate> searchPlacedCompany(String companyId)
            throws RecruitmentException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ArrayList<Candidate> searchPlacedPosition(String position)
            throws RecruitmentException {
        // TODO Auto-generated method stub
        return null;
    }

}

