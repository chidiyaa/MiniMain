package com.cg.rms.dao;

import java.util.ArrayList;

import com.cg.rms.beans.*;
import com.cg.rms.exception.RecruitmentException;

public interface CandidateDAO {

    int addResume(Candidate candidate) throws RecruitmentException;
    int modifyResume(Candidate candidate)throws RecruitmentException;
    ArrayList<Candidate> viewResume(int candidateId)throws RecruitmentException;
    int applyForJob(String jobId,String candidateId)throws RecruitmentException;

}