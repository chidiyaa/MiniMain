package com.cg.rms.dao;

import java.util.ArrayList;

import com.cg.rms.beans.Candidate;
import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.exception.RecruitmentException;

public class CompanyUserDAOImpl implements CompanyUserDAO {

	@Override
	public int registerCompany(CompanyMaster companyMaster)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int postJobRequirement(JobRequirements jobRequirement)
			throws RecruitmentException {
		
		return 0;
	}

	@Override
	public ArrayList<Candidate> searchCandidateQualification(
			String qualification) throws RecruitmentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Candidate> searchCandidatePosition(String position)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Candidate> searchCandidateYearOfExperience(int experience)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
